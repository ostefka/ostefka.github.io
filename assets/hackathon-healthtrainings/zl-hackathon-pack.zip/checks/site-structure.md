# HealthTrainings — target information architecture

Site: the private HealthTrainings destination supplied by the user; use its actual URL.
If structure creation fails, use the [guide's Card 2 manual checklist](https://ostefka.github.io/hackathon-healthtrainings/#the-site-contract-and-manual-creation-fallback).

**Purpose:** one place with exactly **one current, approved version** of each training topic for pharmacy staff, written so that
Copilot agents can answer from it. Not a dump of every source.

## 1. Structure

| Object | Type | URL name | Holds |
|---|---|---|---|
| **Témata** | modern site pages (Site Pages) | `SitePages/<slug>.aspx` | one page per topic: the clean, current counselling guide |
| **Školicí materiály** | document library | `SkoliciMaterialy` | the current file versions (handbook, checklist, slides, leaflet, e-learning script, questionnaire), one file per type per topic |
| **Časté dotazy** | list | `Lists/CasteDotazy` | one item per client question with an approved answer |
| **Katalog školení** | list | `Lists/KatalogSkoleni` | the cleaned course catalogue (from `Katalog-skoleni-2026.xlsx`) |

Nothing else. No "Staré", "Ke schválení" or personal folders: outdated versions and drafts stay where they are (team site,
OneDrive); the publisher records them in **Původní zdroj** but never copies them here.

## 2. Columns — library "Školicí materiály"

| Internal name | Label | Type | Allowed values / rule | Autofill |
|---|---|---|---|---|
| `Tema` | Téma | Choice | Senná rýma a alergie · Nachlazení a chřipka · Ochrana před sluncem · Pálení žáhy a trávení · Problémy se spánkem · Akné a péče o ekzém · Cestovní lékárnička a kinetóza · Hubnutí a regulace hmotnosti · Obecné | yes |
| `TypObsahu` | Typ obsahu | Choice | Příručka · Checklist · Prezentace · Leták · E-learning · Časté dotazy · Dotazník · Rychlá karta · Poznámky z webináře · Katalog · Přehled | yes |
| `CilovaRole` | Cílová role | Choice (multiple) | Farmaceut · Farmaceutický asistent · Vedoucí lékárny · Všichni | yes |
| `Stav` | Stav | Choice | Schváleno · Ke schválení · Archiv (default Ke schválení) | **no, a person sets it** |
| `PlatneOd` | Platné od | Date | date of approval/issue stated in the source | yes |
| `RevizeDo` | Revize do | Date | initially Platné od + 12 months; subsequent human review: §7 | no (rule) |
| `VlastnikObsahu` | Vlastník obsahu | Text | trainer's full name (Text because autofill does not support Person columns) | yes |
| `VerzeObsahu` | Verze | Text | version from the source (e.g. 2.1, 2026) | no |
| `PuvodniZdroj` | Původní zdroj | Multiple lines | where it came from: file paths/links, mail subjects, Teams posts; plus which outdated versions and drafts were found and **not** used | no |
| `Jazyk` | Jazyk | Choice | cs · en | yes |
| `Shrnuti` | Shrnutí | Multiple lines | 2 Czech sentences: what it covers, when to refer to a doctor | yes |
| `KlicovaSlova` | Klíčová slova | Text | 5–8 terms separated by `;` (symptoms, active-ingredient classes, synonyms) | yes |

Only `Tema` and `Stav` are *enforced* as required in SharePoint (so mass uploads don't sit in "required info missing"); the rest is
required by the publishing rule (§5). 8 autofill columns, under Microsoft's recommended maximum of 10 (see the guide).

### Autofill prompts (paste into each column's autofill setting)

| Column | Prompt |
|---|---|
| Téma | Vyber téma, kterému se dokument věnuje. Pokud jde o katalog nebo obecná pravidla, vyber Obecné. |
| Typ obsahu | Urči typ dokumentu podle jeho formy: příručka, checklist, prezentace, leták, e-learning, časté dotazy, dotazník, rychlá karta, poznámky z webináře, katalog nebo přehled. |
| Cílová role | Pro koho je materiál určen? Pokud dokument roli neuvádí, vyber Všichni. |
| Platné od | Datum vydání nebo schválení uvedené v dokumentu (řádek Datum). Pokud chybí, nech prázdné. |
| Vlastník obsahu | Jméno autora uvedené v dokumentu (řádek Autor). |
| Jazyk | Jazyk dokumentu: cs pro češtinu, en pro angličtinu. |
| Shrnutí | Shrň dokument ve 2 větách česky: čemu se věnuje a kdy klienta poslat k lékaři. |
| Klíčová slova | 5 až 8 klíčových slov česky oddělených středníkem (příznaky, skupiny účinných látek). |

Expected values and exact pack upload paths per file: `checks/autofill-expected.csv`. XL-01 uses `autofill/Katalog-skoleni-schvalene-2026.xlsx`, with active courses only. Never upload the messy raw XL-01 or XL-02 to this knowledge site. The 17-file set has no image-only scan. Test SUN-02 OCR separately in a scratch library outside reader-agent knowledge, then remove that scratch copy.

## 3. Lists

**Časté dotazy:** Title = otázka klienta (as a client would ask it) · `Odpoved` (multiple lines, the approved answer, max ~3 sentences,
ends with the referral rule if one applies) · `Tema` (choice, as above) · `Zdroj` (text: the page or file it comes from) · `PlatneOd` (date).

**Katalog školení:** Title = název kurzu · `KurzID` · `Tema` (normalised to the 9 values) · `CilovaRole` · `DelkaMin` (number) ·
`Format` (Prezenčně · E-learning · Webinář) · `VlastnikObsahu` · `PosledniRevize` (date, one format) · `Stav` (Aktivní · Návrh · Archiv).
Only courses with Stav = Aktivní are published. Návrh and Archiv remain outside the knowledge site (lists and workbook uploads alike).

Page properties (Site Pages): `Tema`, `Stav`, `PlatneOd`, `RevizeDo`, `VlastnikObsahu`, `PuvodniZdroj`.

## 4. Naming

- Pages: title = topic name exactly as in `Tema` (e.g. *Senná rýma a alergie*); URL slug without diacritics: `senna-ryma-a-alergie.aspx`.
- Files: `<slug-tematu>-<typ>-<RRRR-MM>.<ext>`, lowercase, no diacritics, no spaces, no "final"/"kopie"/"(1)":
  e.g. `senna-ryma-a-alergie-prirucka-2026-02.docx`, `cestovni-lekarnicka-a-kinetoza-checklist-2026-05.docx`.
- Document title (core property and first heading) = `<Téma> — <Typ obsahu>`.
- One current file per topic and type. A new version replaces the old one (SharePoint version history keeps the old one).

## 5. Topic page template (Czech)

Every topic page has these sections, in this order, with these headings:

1. **Shrnutí** — 2–3 sentences: what the topic is, the goal of counselling.
2. **Na co se klienta zeptat** — numbered questions.
3. **Volně prodejné možnosti podle skupiny účinných látek** — table: Skupina účinných látek · Kdy · Na co upozornit. No brands, no doses: "dávkování dle příbalové informace".
4. **Varovné signály — kdy doporučit lékaře** — bullet list; urgent ones say *volat 155*.
5. **Doplňkový prodej a služby** — campaigns with exact dates, services and how to book them.
6. **Časté dotazy** — 2–5 Q&A (and the same items in the list *Časté dotazy*).
7. **Zdroje a platnost** — Platné od, Revize do, Vlastník, Verze; list of the sources used (with links) and of the outdated/duplicate/draft items found and not used, each with a status reason only. Do not repeat discarded values or draft service details in text, metadata or attachments.

Footer line on every page and file: *Fiktivní školicí materiál pro demo — nejde o odbornou zdravotní radu.*

## 6. What the knowledge agents need (act 3) — design rules

- **The answer must be in the text.** Agents do not filter by column values (Copilot Studio documents column-value queries as
  unsupported; see the guide's act 3). So every key number, date and referral rule is written out in the page body, not only in metadata.
- **One truth per fact.** Only current, approved content lives on the site, even if a trainer requests an exception; conflicting old versions stay outside. This is what makes
  the guide's version-conflict checks answerable.
- **Pages first, files second.** Modern pages are the cleanest source for all three agent platforms; the library holds the same content
  as files for download and for autofill. Keep files short (well under 65 pages; Microsoft tip ≈ 36,000 characters).
- **Descriptive titles.** The GitHub Copilot harness uses the document title as a retrieval signal.
- **Freshness.** Publish at least an hour before act 3; indexing takes minutes, and some Copilot Studio paths take hours.
- **Permissions.** Trainers = owners (edit). Pharmacy staff and the regional manager = Visitors (read); the agents answer with the
  user's permissions. Do not use Restricted Content Discovery on this site.
- **What the site cannot answer** (opening hours, doses, services in draft) is deliberately absent; agents must say so and refer.

## 7. Content-owner maintenance (design clarification)

No new columns. **Initial publication** still sets `RevizeDo = PlatneOd +12 calendar months`. After an actual human review of an
approved library file, the content-owner app may set **only `RevizeDo`** to the actual review date +12 calendar months (clamp 29
February to 28 February in a non-leap year). `PlatneOd` remains the source issue/approval date; extending a review deadline does not
change a source fact. The trainer must open the file and explicitly confirm the review, with old/new date shown before saving.
This lifecycle rule is a local design choice, not a Microsoft product behavior or a claim that reviews have occurred in the tenant.

The app's other allowed file writes are `VlastnikObsahu` (Text: a responsibility handoff, not a separate reviewer assignment) and
`Stav: Ke schválení → Schváleno` after human approval of current content and validation of all metadata. These are **custom metadata**;
they do not publish a page, complete native SharePoint approval or control reader access. Original rejected drafts stay outside
this site. Site Pages, FAQ and catalogue are not written by the app. Confirm native version-history availability for review evidence;
there is no dedicated review log, reviewer/date column or notification workflow in this schema.

A file-metadata change does not synchronise the related topic page or dates written in the document body. The owner reviews those
through Cowork/native editing and republishes as needed before claiming reader guidance changed. When republishing an existing item,
show its current review date and preserve an already-confirmed later deadline unless the trainer explicitly agrees to reset it.
