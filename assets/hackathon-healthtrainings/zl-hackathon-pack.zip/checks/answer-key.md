# Finder answer key

IDs identify the original source items; count each once, including an attachment also copied to the team.
Core files work without mail or Teams. Optional rows count only if you recreated those messages.
Names in files describe fictional authors; your signed-in users and message timestamps will differ.

## Senná rýma a alergie

| ID | Layer | File/message | Expected status |
|---|---|---|---|
| HF-01 | core-file | Senna-ryma-prirucka-v2.1.docx | aktuální |
| HF-02 | core-file | Senna-ryma-prirucka-v1.docx | zastaralé |
| HF-03 | core-file | Alergie_prirucka_kopie.docx | duplikát (HF-01) |
| HF-04 | core-file | Jaro-bez-alergie-2026-skoleni.pptx | aktuální |
| HF-M1 | optional-mail | Jaro bez alergie 2026 — školení a nová příručka | odkaz |
| HF-T1 | optional-teams-post | HF-T1 | odkaz |
| HF-05 | core-file | Allergic-rhinitis-quick-card-EN.pdf | aktuální |

## Nachlazení a chřipka

| ID | Layer | File/message | Expected status |
|---|---|---|---|
| CF-01 | core-file | Nachlazeni-a-chripka-skoleni-2025-26.pptx | aktuální |
| CF-02 | core-file | Chripka_2023.pptx | zastaralé |
| CF-03 | core-file | Nachlazeni-FAQ.docx | aktuální |
| CF-04 | core-file | Nachlazeni-FAQ (1).docx | duplikát (CF-03) |
| CF-M1 | optional-mail | Chřipková sezóna — 3 rychlé tipy pro tárování | aktuální |
| CF-C1 | optional-teams-chat | CF-C1 | odkaz |

## Ochrana před sluncem

| ID | Layer | File/message | Expected status |
|---|---|---|---|
| SUN-01 | core-file | Letak-Bezpecne-leto-2026.pdf | aktuální |
| SUN-02 | core-file | scan_0042.pdf | duplikát (SUN-01) |
| SUN-03 | core-file | Letak-leto-2025.pdf | zastaralé |
| SUN-04 | core-file | Ochrana-pred-sluncem-prirucka-2026.docx | aktuální |
| SUN-M1 | optional-mail | Léto 2026 — podklady ke kampani Bezpečné léto | odkaz |
| SUN-T1 | optional-teams-post | SUN-T1 | odkaz |

## Pálení žáhy a trávení

| ID | Layer | File/message | Expected status |
|---|---|---|---|
| GI-01 | core-file | Paleni-zahy-checklist-v3.docx | aktuální |
| GI-02 | core-file | Paleni-zahy-checklist-v2.docx | zastaralé |
| GI-03 | core-file | Novy dokument (3).docx | duplikát (GI-01) |
| GI-M1 | optional-mail | Pálení žáhy — nový checklist v3 | odkaz |
| GI-T1 | optional-teams-post | GI-T1 | odkaz |

## Problémy se spánkem

| ID | Layer | File/message | Expected status |
|---|---|---|---|
| SLP-01 | core-file | Spanek-e-learning-modul-2026.docx | aktuální |
| SLP-02 | core-file | Spanek-modul-2024.docx | zastaralé |
| SLP-03 | core-file | Spankova-poradna-online-KONCEPT.docx | koncept |
| SLP-04 | core-file | Spankovy-dotaznik-ZL-7.xlsx | aktuální |
| SLP-T1 | optional-teams-post | SLP-T1 | odkaz |

## Akné a péče o ekzém

| ID | Layer | File/message | Expected status |
|---|---|---|---|
| SKN-01 | core-file | Akne-a-ekzem-skoleni-2026.pptx | aktuální |
| SKN-02 | core-file | Akne_ekzem_2024.pptx | zastaralé |
| SKN-03 | core-file | Kozni-poradna-navrh.docx | koncept |
| SKN-M1 | optional-mail | Návrh: Kožní poradna online | odkaz |
| SKN-04 | core-file | Eczema-skin-care-partner-webinar-EN.docx | aktuální |
| SKN-C1 | optional-teams-chat | SKN-C1 | odkaz |

## Cestovní lékárnička a kinetóza

| ID | Layer | File/message | Expected status |
|---|---|---|---|
| TRV-01 | core-file | Cestovni-lekarnicka-checklist-2026.docx | aktuální |
| TRV-02 | core-file | Cestovni_lekarnicka_2023.docx | zastaralé |
| TRV-03 | core-file | Cestovni-lekarnicka-checklist-2026 - kopie.docx | duplikát (TRV-01) |
| TRV-T1 | optional-teams-post | TRV-T1 | odkaz |
| TRV-M1 | optional-mail | Kinetóza — dotaz z pobočky Kolín | aktuální |

## Hubnutí a regulace hmotnosti

| ID | Layer | File/message | Expected status |
|---|---|---|---|
| WGT-01 | core-file | Program-Lehci-krok-2026-prirucka.docx | aktuální |
| WGT-02 | core-file | Prezentace_final_FINAL.pptx | zastaralé |
| WGT-03 | core-file | Weight-management-counselling-guide-EN.pdf | aktuální |
| WGT-M1 | optional-mail | Lehčí krok 2026 — co se mění | odkaz |

## Catalogue and attendance

| ID | Layer | File/message | Expected status |
|---|---|---|---|
| XL-01 | core-file | Katalog-skoleni-2026.xlsx | aktuální |
| XL-02 | core-file | Katalog skoleni (1).xlsx | zastaralé |
| XL-03 | core-file | Certifikace-dochazka-2026.xlsx | aktuální |
| XL-04 | core-file | OTC-matice-temata.xlsx | aktuální |

## Off-topic controls

| ID | Layer | File/message | Expected status |
|---|---|---|---|
| D-MAIL | optional-mail | Teambuilding 9. 10. — menu a alergeny | mimo téma |
| D-TEAMS | optional-teams-post | D-TEAMS | mimo téma |
| D-OD | core-file | Dovolena-2026-plan.xlsx | mimo téma |
| D-SPO | core-file | Inventura-postup-2025.docx | mimo téma |

SUN-02: if OCR is unavailable, report unreadable; do not infer duplicate content from its name.
Files-only HF has 5 items (HF-04 is relocated from mail); CF 4; SLP 4; GI 3; WGT 3; catalogue 4.
CF's paracetamol warning and TRV's driving warning already occur in files. TRV-M1 adds child-age guidance.
Only active courses go to the catalogue list: 14 rows. Exclude KUR-11 (Archiv) and KUR-12 (Návrh).
Leave missing course owners empty: KUR-04/09/14/16. Do not copy document authors into these blanks.

## Card 7 — catalogue topic mappings

| Course | Source topic → destination Téma |
|---|---|
| KUR-08 | Kožní problémy → Akné a péče o ekzém |
| KUR-09 | Cestování → Cestovní lékárnička a kinetóza |
| KUR-15 | GDPR → Obecné |
| KUR-16 | Vitamíny → Obecné |

Keep KUR-15 and KUR-16 among the 14 active courses. Preserve Alan Steiner as KUR-15's owner; leave KUR-16's owner empty.
