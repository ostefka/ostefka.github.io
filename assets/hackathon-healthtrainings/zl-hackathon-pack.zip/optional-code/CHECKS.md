# Optional app checks

Use your actual user, date, site rows and app version. All checks are acceptance
targets, not reported tenant results. Fictional names are metadata values, not
directory accounts. Code build access and every runner's runtime entitlement
must pass the guide's preflight. Use your own SharePoint connection throughout.

| Card | Check and pass evidence |
|---|---|
| A2B-01 | Empty or missing structure: unavailable source is distinguished from genuinely empty; no invented 17/25 totals. |
| A2B-02 | Count native IDs: pages and files separately; folders, home page and FAQ excluded. Eight approved topic pages +17 approved files would total 25, only if those actual rows exist. |
| A2B-03 | Publish another approved topic through Cowork, refresh, reconcile actual added IDs; incomplete catalogue means coverage unavailable. |
| A2B-04 | Incomplete current uploads appear as metadata problems once per item, with every missing/invalid field listed. Do not upload original rejected drafts to manufacture a queue. |
| A2B-05 | Preview-only date fixture D-1/D/D+30/D+31/null gives overdue 1, soon 2, later 1, unknown 1. Use Prague calendar dates and correct leap-day addition. No fixture rows in live data. |
| A2B-06 | Clean catalogue has 14 active courses, eight clinical topics plus Obecné; no KUR-11/12. Owner gaps KUR-04/09/14/16 remain blank. General courses require course-level verification. |
| A2B-07 | Cancel ownership handoff: no change. Confirm: only VlastnikObsahu changes; reload native values/history and a second trainer's view. Text ownership does not notify or grant rights. |
| A2B-08 | After actually reviewing a current approved file, change only RevizeDo to today's date +12 calendar months. PlatneOd, page and document body remain unchanged. |
| A2B-09 | Approve only a vetted current file with all 12 metadata fields valid and a non-overdue review date. Only Stav changes; no page publication or permission change is implied. |
| A2B-10 | Shared app: second trainer uses own connection and sees persisted change. Entitled read-only and no-site-access controls enforce service permissions; no previous user's cached data. App sharing grants no data access. |
| A2B-11 | Preview failures, cancellation and competing edit: no false success, preserve other fields. Require conditional version/ETag updates; unsupported means disabled writes/native forms and v2 pending. |
| A2B-12 | Force pagination, inspect all source statuses, stale/error states, keyboard operation and chart/table agreement. After explicit Publish/Share, check the live app with another entitled trainer. |

The four source catalogues/matrices are not four topic pages. Autofill does not
set Stav, RevizeDo, VerzeObsahu or PuvodniZdroj. Complete and review those before
calling content approved. Initial review deadline is source issue date +12 months;
a confirmed later human review may extend it. Preserve legitimate later reviews.
Do not change site permissions or policies merely to make a failing check pass.
