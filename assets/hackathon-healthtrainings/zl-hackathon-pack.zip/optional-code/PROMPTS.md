# Copilot Code — exact build prompts

Prepared **2026-11-08** for fictional **Lékárny Zelený list**. These prompts design an app; no app was built or tenant changed by
this job. Run as **your own trainer account**, in the Microsoft 365 Copilot app's **Code** tab, **cloud** session, after the guide's optional Code preflight.
Use one conversation; paste each fenced block in order, check the result, then continue. If Code needs a data-source consent,
choose the existing HealthTrainings SharePoint source under your signed-in account. Never substitute a maker-owned shared connection.
The display path below is sufficient; do not paste tenant IDs, tokens or seeder credentials.

Product basis: [Code build/preview/publish/share](https://learn.microsoft.com/en-us/copilot/code/use-code),
[Managed Runtime connector model](https://learn.microsoft.com/en-us/microsoft-365/copilot-managed-runtime/developer/apps/connect-to-data).
An attached file can inform a build; it is not a live SharePoint connection.

## v1 — read-only content-health dashboard

```text
Vytvoř interní aplikaci „Zelený list — Zdraví obsahu“ pro fiktivní síť Lékárny Zelený list.
Použij cloudovou relaci Copilot Code a Copilot Managed Runtime. Uživatelé: přihlášený uživatel a skuteční spoluhráči.
Alan Steiner, Andre Lawson, Carlos Slattery a Serena Ribeiro jsou pouze fiktivní
hodnoty autorských/vlastnických metadat. Nejsou to účty pro sdílení ani výběr uživatelů.
Pro sdílení a výběr uživatelů použij pouze přihlášený účet a skutečné spoluhráče.
Potřebují opakovatelný přehled a přesné počty, ne chat. V1 je pouze pro čtení.
Nezveřejňuj ani nesdílej aplikaci v této iteraci.

Připoj EXISTUJÍCÍ web „Health Trainings — Zelený list“:
<URL webu>
Použij spravovaný konektor SharePoint (shared_sharepointonline), přihlášeného uživatele
a jeho vlastní připojení. Nejprve ověř skutečné schéma a vazby. Nevytvářej web, seznamy,
knihovny ani sloupce. Nečti zdrojový tým, poštu ani OneDrive. Žádná databázová kopie,
Work IQ volání, přímé fetch/Graph/REST požadavky, tajné klíče nebo externí backend.
Neobcházej pravidla konektorů. Pokud něco nelze připojit, ukaž konkrétní překážku.

Datový kontrakt — názvy za „=“ jsou INTERNÍ názvy; zachovej je přesně:
1. Knihovna „Školicí materiály“, cesta SkoliciMaterialy:
   Téma=Tema (Choice), Typ obsahu=TypObsahu (Choice), Cílová role=CilovaRole
   (více hodnot), Stav=Stav (Choice), Platné od=PlatneOd (Date),
   Revize do=RevizeDo (Date), Vlastník obsahu=VlastnikObsahu (Text, nikoli Person),
   Verze=VerzeObsahu (Text), Původní zdroj=PuvodniZdroj (víceřádkový text),
   Jazyk=Jazyk (Choice cs/en), Shrnutí=Shrnuti (víceřádkový text),
   Klíčová slova=KlicovaSlova (Text).
   Stav: Schváleno / Ke schválení / Archiv.
   TypObsahu: Příručka / Checklist / Prezentace / Leták / E-learning /
   Časté dotazy / Dotazník / Rychlá karta / Poznámky z webináře / Katalog / Přehled.
   CilovaRole: Farmaceut / Farmaceutický asistent / Vedoucí lékárny / Všichni.
2. „Témata“ jsou stránky v Site Pages, cesta SitePages, nikoli seznam jménem Témata.
   Čti jen šest vlastních polí Tema, Stav, PlatneOd, RevizeDo, VlastnikObsahu,
   PuvodniZdroj. Do přehledu stránek patří osm klinických tematických stránek podle
   přesného názvu tématu nebo URL slugu bez diakritiky z názvu tématu; ne Home.aspx,
   zpravodajství nebo domovská stránka. Při nejasné identifikaci ukaž problém.
3. Seznam „Katalog školení“, cesta Lists/KatalogSkoleni:
   Title (název kurzu), KurzID (ID kurzu), Tema, CilovaRole, DelkaMin (Délka (min)),
   Format (Formát), VlastnikObsahu, PosledniRevize (Poslední revize), Stav.
   Jeho Stav má JINÉ hodnoty: Aktivní / Návrh / Archiv.
   Je to vyčištěná projekce aktuálního Excelu Katalog-skoleni-2026.xlsx (XL-01),
   kterou sem publikuje Cowork. Neimportuj a nepřepisuj katalog z aplikace.
4. Seznam „Časté dotazy“ (Lists/CasteDotazy) do této aplikace NEPŘIPOJUJ.
   Jeho řádky nejsou další školicí materiály a nemají RevizeDo ani VlastnikObsahu.
Vedle těchto obchodních polí použij pouze existující systémové údaje pro ID,
titulek/jméno souboru, odkaz, rozlišení souboru/složky a verzi/ETag. Nic nezapisuj.

Přesné hodnoty Tema:
Senná rýma a alergie; Nachlazení a chřipka; Ochrana před sluncem;
Pálení žáhy a trávení; Problémy se spánkem; Akné a péče o ekzém;
Cestovní lékárnička a kinetóza; Hubnutí a regulace hmotnosti; Obecné.

Načti všechny dostupné řádky s úplným stránkováním, bez složek a bez dvojího
započtení stejného ID ve stejné knihovně. Stránka a soubor jsou dvě různé položky.
Počty vypočítej deterministicky z načtených dat; žádné odhady, pevná demo čísla,
vyhledávací úryvky nebo generování odpovědí modelem. Žádné pravidelné dotazování.
Přidej tlačítko Obnovit, čas posledního úspěšného načtení a stav každého zdroje.
Při přihlášení jiného uživatele nenačítej cache předchozího. Neskladuj data v localStorage.

Definice:
- Hlavní počet „Schváleno dle metadat“ = položky se Stav přesně Schváleno.
  Zvlášť stránky a soubory, vedle sebe součet. Nejde o důkaz nativního zveřejnění,
  schválení obsahu SharePointem nebo viditelnosti pro čtenáře. Přidej vysvětlení.
- Čeká na schválení = Stav Ke schválení. Archiv ukaž odděleně, vynech jej z problémů
  a pokrytí. Neplatný/chybějící Stav je problém metadat, nikoli schválení.
- U každého nearchivního souboru kontroluj všech 12 výše uvedených polí, u stránky
  šest vlastních polí. Prázdný/whitespace text, prázdné pole hodnot, neplatné datum
  nebo neplatná volba = problém. Jedna položka se dvěma chybami se počítá jednou.
  V detailu vypiš konkrétní chybějící/neplatná pole; nevyplňuj je sám.
- D = dnešní kalendářní datum v Europe/Prague. Po revizi: RevizeDo < D.
  Revize do 30 dnů: D <= RevizeDo <= D+30 kalendářních dnů (oba kraje včetně).
  Později: RevizeDo > D+30. Chybějící/neplatné RevizeDo je jen problém metadat.
  Kategorie data jsou disjunktní; problém metadat se s datovou kategorií může překrývat.
- Pokrytí: unikátní platná Tema z kurzů se Stav Aktivní porovnej s tématy alespoň
  jedné stránky NEBO souboru se Stav Schváleno. Označ „Pokrytí schváleným obsahem“.
  Revize je samostatný ukazatel; prošlá revize sama nezruší pokrytí.
  Klinických témat je osm. Obecné ukaž zvlášť a obecné kurzy označ
  „Nutno ověřit po kurzech“: obecný katalog či matice neprokazuje obsah každého kurzu.
  Zobraz aktivní kurzy bez vlastníka odděleně od nedostatků souborů/stránek.
  Návrh a Archiv z katalogového pokrytí vyluč. Nepřekládej synonyma témat za běhu.
  Neplatná nebo chybějící Tema ukaž ve frontě Bez tématu / Neplatné téma.
- Když seznam nebo sloupec neexistuje, přístup selže nebo načtení není úplné,
  ukaž „Nelze vyhodnotit“, nikoli nulu nebo úspěch. Částečné počty výslovně označ.
  Bez Site Pages lze ukázat jen soubory; celkové pokrytí nevyhodnocuj.
  Prázdný katalog znamená „Katalog zatím nezveřejněn“, nikoli 100% pokrytí.
  Všechny počty jsou jen pro data přístupná aktuálnímu uživateli, ne audit celého tenantu.

Obrazovky:
1. Přehled témat — všech devět témat, počty stránek/souborů, problémů metadat,
   po revizi, do 30 dnů, čekajících; filtr téma/vlastník/stav/zdroj.
2. Fronta oprav — tabulka, řazení, detail položky s přesnými metadaty a odkazem
   Otevřít v SharePointu. V1 neobsahuje žádnou zapisovací akci.
3. Pokrytí katalogu — aktivní kurzy včetně KurzID, názvu, tématu a vlastníka,
   nepokrytá klinická témata a samostatně Obecné a chybějící vlastníci.
Globální KPI a pokrytí vycházejí z celého dostupného načteného stavu; filtr tabulky
je nemění. Filtrovanou tabulku označ „Zobrazeno X z Y“. Nepřepočítávej pokrytí jen
z aktuální stránky výsledků. Zachovej odkazy do zdrojového webu.

České rozhraní, střídmá zelená, čitelné tabulky. V patičce:
„Fiktivní školicí materiál pro demo — nejde o odbornou zdravotní radu.“
Nevytvářej zdravotní rady ani obsah školení. Nezaváděj nový schvalovací systém.
Na konci vypiš skutečně připojené zdroje a podporované operace; neověřené schopnosti
označ. Jestli konektor část smlouvy neumí, nech příslušnou funkci nedostupnou.
```

**Check before v2:** A2B-01–06 and the read path of A2B-11/12. In the seeded empty state expect an IA prerequisite message, not
17 live files. After publication compare actual row IDs and counts with CHECKS.md, including the separate page/file totals and
four catalogue owner gaps. Open one topic page and file through their real links. Incomplete Site Pages support is a partial result.

## v2 — explicit maintenance actions on library files

```text
Rozšiř stejnou aplikaci o potvrzované akce pouze nad soubory knihovny
„Školicí materiály“ na <URL webu>
Zachovej datový kontrakt, výpočty a chybové stavy v1. Nic nezveřejňuj ani nesdílej.
Neměň Site Pages, katalog, FAQ, obsah souboru, schéma nebo oprávnění. Žádné hromadné akce.

Povol zápis pouze do těchto tří existujících polí, vždy jen pole vybrané akce:
1. „Předat vlastnictví / revizi“: VlastnikObsahu. Je to TEXTOVÉ pole vlastníka,
   nikoli Person nebo samostatný recenzent. Nabídni pouze TEXTOVÉ hodnoty metadat Alan Steiner, Andre Lawson,
   Carlos Slattery, Serena Ribeiro, nikoli adresářový výběr uživatelů. Pro sdílení
   a uživatelské výběry použij přihlášený účet a skutečné spoluhráče; ukaž „Změní odpovědného vlastníka; nikoho
   neupozorní a neudělí přístup“. Nepřidávej Reviewer, AssignedTo ani sloupec úkolu.
2. „Potvrdit provedenou revizi“: pouze RevizeDo. Jen u souboru Stav=Schváleno.
   Vynucuj otevření souboru a výslovné potvrzení „Obsah jsem zkontroloval/a“.
   Datum skutečné revize je dnešek v Europe/Prague; nové RevizeDo = dnešek +12
   kalendářních měsíců (29. 2. -> 28. 2. v nepřestupném roce).
   První publikace stále inicializuje RevizeDo=PlatneOd+12 měsíců; následná lidská
   revize podle IA §7 plánuje další kontrolu. Neměň PlatneOd ani text dokumentu.
   Ukaž přesné staré a nové datum; neprodlužuj datum bez potvrzení skutečné revize.
   Připomeň, že související stránka a datum v těle dokumentu se tím nezmění.
3. „Schválit metadata“: pouze Stav, přechod Ke schválení -> Schváleno.
   Povol jen při úplných/platných všech 12 metadatech a RevizeDo>=dnešek.
   Vyžaduj otevření souboru a potvrzení, že obsah je věcně schválený.
   Ukaž „Mění jen metadata. Nenahrazuje publikaci, nativní schválení ani oprávnění.“
   Archiv, stránka, neúplná či neplatná metadata = akce nedostupná s důvodem.
   Nepřesouvej sem originální zamítnuté návrhy a nikdy je automaticky neschvaluj.

Každá akce: detail zdroje a ID -> znovu načíst aktuální řádek -> zobrazit staré/nové
hodnoty -> Potvrdit / Zrušit -> podmíněný zápis dle verze/ETag -> načíst ze SharePointu
výsledek a obnovit přehled. Zapisuj pod vlastní identitou přihlášeného uživatele.
Nedělej optimistický úspěch. Při timeoutu nejprve znovu ověř stav, neposílej slepě další
zápis. Při konfliktu zachovej cizí změny a nabídni nové načtení.
Pokud dostupná operace konektoru neumí podmíněný zápis nebo by smazala jiná pole,
zápis v aplikaci nepovoluj a nabídni nativní formulář položky v SharePointu.
Samotné přečtení před uložením NEZARUČUJE ochranu souběhu. Neobcházej to HTTP akcí.
Když aktualizační operaci blokuje politika nebo uživatel nemá právo měnit položku,
ukaž konkrétní překážku, zachovej čtení a odkaz do SharePointu. Jména v nabídce nejsou
autorizace; bezpečnost vynucuje konektor a SharePoint. Žádný účet vlastníka za ostatní.

Bez nové auditní tabulky: ukaž odkaz na položku a instruuj kontrolu nativní historie
verzí. Pokud historie není zapnutá, nepředstírej audit provedené revize. Žádné nové
sloupce ReviewedBy/ReviewedAt, upozornění ani přepis PuvodniZdroj kvůli logování.
```

**Check before v3:** A2B-07–11. Cancel changes nothing. Inspect native values/history after each successful write and compare all
other fields. Reopen in a second trainer's session. If conditional updates are unavailable, the disabled button/native-form
fallback is correct, but **v2 write capability remains pending**. Do not claim the app passed the full write demo.

## v3 — polish and prepare the handover

```text
Vylepši stávající aplikaci bez změny zdrojů, oprávnění, výpočtů nebo rozsahu zápisů.
Nevkládej ukázková data do živého režimu. Nic zatím nepublikuj ani nesdílej.

Přidej malý sloupcový graf „Položky po revizi podle tématu“ včetně dostupné tabulkové
alternativy; kresli jej lokálně z již načtených dat, bez CDN, externích fontů/obrázků
nebo analytiky. Barvy doplň textem a ikonou. Ovládání klávesnicí, popisky formulářů,
viditelný focus, rozumná šířka na notebooku. Tabulky a detail musí zůstat hlavní.

Odliš načítání, skutečně prázdný zdroj, chybějící strukturu, odepřený přístup,
odpojený konektor, neúplné stránkování a zastaralý poslední úspěšný stav.
Starý stav označ a nepoužívej ho pro zápisy. Umožni ruční Obnovit bez automatického
pollingu. Globální počty jsou za dostupné zdroje a patří k zobrazenému času a datu.
Ponech jasné rozlišení „Schváleno dle metadat“ a nativního zveřejnění obsahu.

Připrav stručný přehled připojených zdrojů, známých nepodporovaných operací,
ověřených testů a kroků pro zveřejnění a sdílení. Uživatel aplikaci najde na
managedapps.cloud.microsoft. Sdílení aplikace samo nesdílí data ani licenci.
Ověř načtení a čitelnost publikované varianty až po mém samostatném pokynu.
```

**Check:** A2B-12 plus re-run any card whose behavior changed. Test with page size deliberately reduced in the preview to force
multiple connector pages; never test completeness by merely seeing the first screen. Ensure packaged chart assets work under CSP.

## Publish and share

After checks, use Code's Publish and Share controls. Choose actual internal hackathon teammates, each with their own connection and runtime entitlement. The fictional names in the exercise are content authors, not directory accounts.
