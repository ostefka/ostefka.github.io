Reference copies only. Upload each workbook ONCE, from 01-OneDrive or 02-Team-Skoleni.
Raw catalogues contain withdrawn/draft rows: never upload them to HealthTrainings.
