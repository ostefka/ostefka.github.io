---
name: rychle-hledani-schvalenych
description: Rychlé vyhledání ve schválených materiálech webu, který má agent jako znalost. Použij u každé odborné otázky personálu (příznaky, kdy poslat k lékaři, kampaně, služby, programy, kurzy, dotazníky). Nepoužívej na pozdravy a dotazy mimo práci.
metadata:
  version: "1.0-starter"
  surface: Copilot Studio (Microsoft Copilot harness)
---

Cíl: odpovědět rychle, z jednoho hledání, jen ze schválených materiálů.

1. Udělej jedno hledání: sharepoint_semantic_search, size 4, dotaz 3–6 českých klíčových slov tématu.
2. Filtr podle metadat ve výsledcích: ber jen položky, jejichž souhrn uvádí Schváleno, nebo stránku tématu (.aspx). Přednost má
   stránka tématu, pak checklist nebo příručka s nejnovějším datem v názvu. Položky Koncept, Ke schválení, Archiv nebo
   s návrh/koncept/draft v názvu ignoruj.
3. Druhé hledání (sharepoint_lexical_search, size 4) jen když první nevrátí žádnou stránku ani soubor k tématu. Víc hledání nedělej.
4. Neotevírej celé dokumenty, stačí souhrny z výsledků.
5. Odpověz hned: nejvýš 4 věty, varovné signály první, čísla přesně jako ve zdroji, na konci Zdroj: název stránky nebo souboru.
   Neplatné zdroje ani jejich hodnoty nezmiňuj.
6. Když schválené materiály odpověď nemají, řekni to a pošli za školitelem.
