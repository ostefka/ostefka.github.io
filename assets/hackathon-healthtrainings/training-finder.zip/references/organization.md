# Our organization (fill in with Cowork)

Replace every `<…>` with your own details. Ask Cowork to do it with you: tell it in your own words, and let it update this file.

## Company

- Company / brand: `<name>`
- Who uses this skill: `<e.g. internal trainers of the pharmacy network>`

## Topics

| Topic (exact name used on the site) | Owner | Search terms (synonyms, words without diacritics, English) |
|---|---|---|
| `<topic 1>` | `<name>` | `<terms>` |
| `<topic 2>` | `<name>` | `<terms>` |

## Where training material lives

- Teams teams and channels: `<team › channel>`
- SharePoint sites and folders: `<site › library › folder>`, including archive and approval folders
- OneDrive: `<whose OneDrive, which folders>`
- Mail: `<typical senders or subjects>`

## Words we use

- Approved: `<e.g. Schváleno>`
- Draft: `<e.g. Koncept, Návrh, Neschváleno, Nepublikovat>`
- Withdrawn: `<e.g. Staženo, Zastaralé>`

## Never use as a source

- `<places or files to ignore>`
