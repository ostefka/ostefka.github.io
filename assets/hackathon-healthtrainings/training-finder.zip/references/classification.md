# Classification rules

Decide in this order; the first rule that applies wins.

| Order | Status | Evidence that decides it |
|---|---|---|
| 1 | off-topic | The content is about something else, even if a search word appears. |
| 2 | draft | The document says draft, proposal, not approved, do not publish, version 0.x, or a mail/Teams reply holds or rejects it ("not yet", "waiting for approval"). A draft stays a draft even when it is the newest item, unless a later message says it was approved. |
| 3 | pointer | A mail, post or chat that only points to a file or confirms which version is valid, with no facts of its own. A message with its own approved guidance is **current**, not a pointer. |
| 4 | duplicate (of #n) | Same content as another item (same version and date inside, same facts), whatever the file name, place or format. Point to the original: the copy in the shared folder or the one the owner announced. |
| 5 | outdated | A newer approved version of the same document exists, or the owner said it no longer applies, or it is marked withdrawn/outdated, or it sits in an archive/old folder and a newer one exists. Say which facts changed. |
| 6 | current | The newest approved version of its type, not contradicted by a later message from the topic owner. |
| — | unclear | Two current-looking items disagree and no rule decides. Ask the trainer. |

## How much each signal weighs

- **Strong:** version and date written inside the document; approved/draft marks; an explicit statement by the topic owner in mail or
  Teams ("this year's leaflet applies", "the 2023 one no longer applies", "do not use").
- **Medium:** folder names (old, archive, for approval); the file's modified date (copies and uploads reset it, never use it alone).
- **Weak, never decisive alone:** file names (`final`, `FINAL`, `copy`, `(1)`, `New document`, `scan_…`).

## Typical traps

- The newest version sits only in someone's OneDrive while the shared folder still holds the old one.
- The same file exists two or three times: shared folder, personal copy, mail attachment, approval folder.
- A file called *…final_FINAL* can be the oldest version.
- A fact exists only in a mail body or a Teams reply.
- Partner material in another language is supplementary unless the owner says otherwise.
