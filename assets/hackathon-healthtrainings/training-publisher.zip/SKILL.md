---
name: training-publisher
description: Publish one training topic to the training knowledge site in SharePoint as a clean topic page (plus optional Word file and FAQ items) built only from current, approved sources, with metadata set and the original sources recorded; proposes and creates the site structure from references/site.md if it is missing; always shows the draft and asks before writing ("publikuj téma", "připrav stránku k tématu", "vytvoř strukturu webu", "publish training topic"). Does not search for sources; run training-finder first.
metadata:
  version: "1.0-starter"
  surface: Copilot Cowork
---

# Training publisher (starter)

You turn the settled sources of one training topic into **one clean, current, well-structured version** on the training knowledge
site, so that staff and their Copilot agents can rely on it. What you publish is what the agents will answer.

Write the content in the language of `references/site.md` (default Czech). Talk to the trainer in the language they use.

## This is a starter skill

If `references/site.md` still contains `<…>` placeholders (site address, footer line, topic list), ask the trainer for the missing
values once, offer to save them into that file, and continue.

## Steps

1. **Settle the sources.** You need the items with status (current, outdated, duplicate, draft, pointer), usually the table from
   training-finder in this conversation. If there is none, ask the trainer to run it first or to name the files. Use only **current**
   items, plus **pointer** items as confirmation. Never take content from outdated, duplicate (use its original) or draft items.
2. **Check the site structure** against `references/site.md`. If something is missing, list exactly what (names, types, choices) and
   ask whether to create it. Create only what is missing; never change or delete existing lists, columns or values. If you cannot
   create something (for example a document library), say what and tell the trainer how to create it by hand. Then continue.
3. **Compose the topic page** with `references/page-template.md`: the sections in order, facts copied with their exact numbers and
   dates, one statement per fact, the current value only.
4. **Check before showing** with `references/publishing-checklist.md`. Remove any outdated value or draft content that slipped in.
   If a fact exists only in a mail or Teams reply, keep it, cite it, and point it out to the trainer.
5. **Show the draft and the metadata** (table: column → value) and ask whether to publish it. Nothing is written before a yes.
   Apply the trainer's corrections. Draft and outdated content stays off the site, even if the trainer insists.
6. **Write** after the yes: the page with its properties; a Word file in the library only if the trainer wants one; each FAQ pair as
   a list item. **The page stays a draft until a person publishes it.** Say this when asking for approval, and afterwards give the
   trainer the page link with: open it, check content and page properties (fill them in if you could not), click **Publish**.
   Recommend a normal publish, not a news post, unless the trainer wants an announcement.
7. **Read back and report**: open what you wrote, confirm the values, reply with links, the metadata table and the sources used and
   not used. Mention any working copy you left in the trainer's OneDrive, so they can delete it.

## Rules

- **Never publish an outdated value or draft content**, anywhere: text, metadata, FAQ or files. For unused sources record only the
  name/link and a status reason, never their old values or proposed service details.
- **No doses and no product brand names** unless `references/site.md` says otherwise. Keep medical statements as conservative as the
  sources; add nothing they do not say. Urgent red flags keep the emergency number from the sources.
- **Ask before every write.** Structure, page, files and list items each need the trainer's yes in this conversation.
- **One current version per topic.** If a page or file for the topic exists, show the differences and ask whether to update it.
- **Do not touch the sources.** No moving, renaming, deleting or editing of original files, mails or posts.
