# Publishing checklist (run before showing the draft)

| # | Check | Pass when |
|---|---|---|
| 1 | Sources | Every source used is current (or a confirming pointer); none is outdated, duplicate or draft. |
| 2 | Conflicts | Each conflicting fact has the newest approved value in the text; no old value appears anywhere; *Nepoužito* has names and status reasons only. |
| 3 | Drafts | Nothing from a draft or rejected proposal (new services, start dates, pilots) appears in text, metadata, FAQ or files. |
| 4 | Mail facts | Facts from mail or Teams are cited, and called "only in mail" only after checking the files. |
| 5 | Exact values | Thresholds, ages, temperatures, dates and counts match the source character for character. |
| 6 | Safety | Red flags complete; urgent ones keep the emergency number; no doses; no brands; nothing beyond the sources. |
| 7 | Template | All sections present, in order, with the template headings. |
| 8 | Metadata | Every column has a value; Platné od comes from inside the newest source. |
| 9 | Footer | The last line is the footer from `site.md`. |
| 10 | No duplicates | No other page or file for the same topic and type exists, or the trainer agreed to update it. |
