# Topic page template

Title = the exact topic name. Sections in this order with these headings. Short sentences; numbers exactly as in the source;
Czech dates `15. 2. 2026`; every key fact in the text, because agents do not read metadata as facts.

```
# <Téma>

## Shrnutí
<2–3 věty: o čem téma je a jaký je cíl rozhovoru s klientem.>

## Na co se klienta zeptat
1. <otázka>

## Volně prodejné možnosti podle skupiny účinných látek
| Skupina účinných látek | Kdy | Na co upozornit |
|---|---|---|
| <skupina> | <použití> | <upozornění; dávkování dle příbalové informace> |

## Varovné signály — kdy doporučit lékaře
- <pravidlo s přesným číslem, např. "příznaky se nezlepší po 14 dnech samoléčby">
- <urgentní stav — volat 155>

## Doplňkový prodej a služby
- <kampaň s přesnými daty, služba a jak se objednat>

## Časté dotazy
**<otázka klienta>**
<schválená odpověď, max 3 věty>

## Zdroje a platnost
Platné od: <datum> · Revize do: <datum> · Vlastník: <jméno> · Verze: <verze>
Použité zdroje:
- <název> — <místo, odkaz> (<verze, datum>)
Nepoužito:
- <název> — <místo> — <zastaralé / duplikát / koncept>

---
<patička ze site.md>
```
