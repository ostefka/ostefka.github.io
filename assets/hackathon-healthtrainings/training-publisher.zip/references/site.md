# The training knowledge site (default proposal, adjust with Cowork)

Replace every `<…>` and change anything that does not fit your organization. Ask Cowork to do it with you.

- Site address: `<https://…/sites/…>` (if empty, use the address the trainer gives in the prompt; ask if none)
- Content language: Czech
- Footer line on every page and file: `<e.g. Interní školicí materiál. Platí verze na tomto webu.>`
- Brand names and doses: not allowed (write "dávkování dle příbalové informace")

**Purpose:** exactly **one current, approved version** of each topic, written so that people and Copilot agents can answer from it.
Not a copy of every source: drafts and old versions stay where they are.

## Structure

| Object | Type | Holds |
|---|---|---|
| Topic pages | site pages | one page per topic, sections from `page-template.md` |
| **Školicí materiály** | document library | current files, one per type per topic (optional) |
| **Časté dotazy** | list | one item per client question with an approved answer |

## Columns of the library *Školicí materiály*

| Column | Type | Values / rule |
|---|---|---|
| Téma | Choice | the topic list below |
| Typ obsahu | Choice | Příručka · Checklist · Prezentace · Leták · E-learning · Dotazník · Rychlá karta |
| Cílová role | Choice (multiple) | `<your roles, e.g. Farmaceut · Farmaceutický asistent · Vedoucí lékárny · Všichni>` |
| Stav | Choice | Schváleno · Ke schválení · Archiv (a person sets it) |
| Platné od | Date | approval or issue date written in the source |
| Revize do | Date | Platné od + 12 months |
| Vlastník obsahu | Text | the topic owner's name |
| Verze | Text | the version written in the source |
| Původní zdroj | Multiple lines | sources used (name, place, link), then *Nepoužito:* with name and status reason only |
| Shrnutí | Multiple lines | 2 sentences: what it covers, when to refer to a doctor |
| Klíčová slova | Text | 5–8 terms separated by `;` |

**Časté dotazy** list: Title = the client's question · Odpověď (multiple lines) · Téma (choice) · Zdroj (text) · Platné od (date).

**Page properties:** Téma, Stav, Platné od, Revize do, Vlastník obsahu, Původní zdroj.

## Topics

`<topic 1>` · `<topic 2>` · `<…>` · Obecné

## Naming

- Page title = the topic name; URL without diacritics: `senna-ryma-a-alergie.aspx`.
- Files: `<topic-slug>-<type>-<YYYY-MM>.docx`, lowercase, no diacritics, no "final" or "(1)".

## What agents need

- Every key number, date and referral rule written in the page text, not only in metadata.
- One truth per fact: only the current version lives here.
- Staff get read access; trainers edit.
